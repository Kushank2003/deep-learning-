import tensorflow as tf
tf.__version__